import React, { useState } from 'react';
import './App.css';

import MailContent from './MailContent';
import ResponsiveDrawer from './Mail';

function App() {
  return (
    <div className='Project'>
      <ResponsiveDrawer/>
    </div>
  )
}

export default App;